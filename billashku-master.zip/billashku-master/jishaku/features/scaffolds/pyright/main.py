from typing import *  # type: ignore

{content}
